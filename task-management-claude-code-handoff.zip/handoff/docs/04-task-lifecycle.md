# Alur Status Task

Ada **dua alur berbeda** yang harus dibedakan dengan tegas — banyak bug di masa prototyping muncul justru karena keduanya tercampur:

1. **Alur task induk** (root task, `parent = null`) — melewati status penuh termasuk review dan closing PMO.
2. **Alur sub-task** (`parent` terisi) — siklus sendiri yang jauh lebih sederhana, **tidak** melewati review atau PMO sama sekali.

## Alur sub-task (sederhana, disebut "Opsi A" dalam riwayat diskusi)

```
To do  →  [PIC klik "Kerjakan"]  →  On Progress  →  [PIC klik "Selesai"]  →  Done
```

- PIC sub-task bebas menandai sub-tasknya sendiri Done, **tanpa perlu reviewer atau PMO sama sekali**. Reviewer/PMO hanya terlibat di level task induk, setelah SEMUA sub-task Done.
- PIC task induk (bukan cuma PIC sub-task itu sendiri) juga berhak CRUD penuh atas semua sub-task di bawah task induknya (tambah, ubah, hapus) — bukan cuma sub-task yang PIC-nya dirinya sendiri.
- Kalau task induknya punya flag `sequential = true`: sub-task terkunci berurutan — sub-task ke-N tidak bisa dikerjakan sebelum sub-task ke-(N-1) mencapai progress 100%. Begitu satu sub-task selesai dan sub-task berikutnya jadi terbuka, **PIC sub-task berikutnya otomatis dapat notifikasi** ("Giliran kamu: … sudah bisa dikerjakan").
- Sub-task **tidak pernah** bisa mencapai status `On Review` atau `Revisi` — dua status itu eksklusif milik task induk.

## Alur task induk (lengkap)

```
                    ┌──────────────────────────────────────────┐
                    │                                            │
  To do  →  On Progress  →  [ajukan review]  →  On Review  →  Revisi
                    ↑                              │              │
                    └──────────[ajukan ulang]──────┘←─────────────┘
                                                     │
                                    (semua sub-task Done DAN
                                     semua reviewer Accept,
                                     atau tidak ada reviewer)
                                                     ↓
                                                   Done
                                        (masih tampil di board Kanban)
                                                     │
                                          [PMO/Pengelola klik Closing]
                                                     ↓
                                            Done + closeVia terisi
                                       (hilang dari board, tetap di Laporan)
```

### Aturan progres task induk

Progress task induk **tidak diisi manual** — selalu dihitung dari sub-task:

```
progress induk = (jumlah sub-task berstatus Done) / (total sub-task) × 100
```

Bukan rata-rata angka progress tiap sub-task. Contoh: 1 dari 3 sub-task Done → 33,3%, bukan rata-rata persentase progress masing-masing. *(Ada opsi alternatif "berbobot menurut durasi sub-task" sebagai pengaturan sistem opsional — sub-task yang lebih panjang durasinya menyumbang bobot progress lebih besar. Default: tidak berbobot / hitung rata jumlah.)*

Start/End task induk juga dihitung otomatis: tanggal paling awal dan paling akhir dari seluruh sub-tasknya.

**Task induk tanpa sub-task sama sekali** (task tunggal) progress-nya diisi manual seperti biasa oleh PIC.

### Kenapa task induk tidak boleh langsung mencapai "Done" dari progress 100%

Ini poin krusial yang sempat jadi bug nyata di prototipe: **task induk TIDAK BOLEH otomatis berubah status jadi Done** hanya karena progress mencapai 100% (baik karena semua sub-task selesai, atau karena field progress diisi manual 100 pada task tanpa sub-task). Status `Done` untuk task induk **hanya boleh dicapai lewat closing PMO/Pengelola**, setelah lolos alur review. Kalau progress mencapai 100% tapi belum diajukan review, status tetap `On Progress` — tombol "Ajukan untuk Review" yang muncul, menandakan task sudah siap diajukan.

### Kenapa task tidak langsung hilang dari board begitu Done

Status `Done` dan "sudah ditutup" (`closeVia` terisi) adalah **dua momen berbeda**:
- **Done tapi belum ditutup**: task sudah lolos semua reviewer (atau tidak ada reviewer), tapi PMO/Pengelola belum klik tombol closing. Task ini **tetap tampil di board Kanban**, di kolom "Done", supaya PMO tahu ada yang menunggu ditutup.
- **Done dan sudah ditutup** (`closeVia` terisi): baru sekarang task hilang dari board dan pindah jadi arsip (tetap terlihat di halaman Laporan).

## Papan Kanban: lima kolom

```
To do │ On Progress │ Revisi │ On Review │ Done
```

Kolom **Done** di board hanya berisi task yang `status = 'Done'` DAN `closeVia` masih kosong. Begitu `closeVia` terisi, task itu disaring keluar dari board sepenuhnya.

## Laporan sebagai arsip

Tidak ada halaman "Arsip" terpisah — halaman **Laporan** (dikelompokkan per Project) menampilkan task apa adanya termasuk yang sudah closing, sehingga otomatis berfungsi sebagai arsip tanpa perlu membangun tampilan kedua.
