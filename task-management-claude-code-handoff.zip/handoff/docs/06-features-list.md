# Checklist Fitur Lengkap

Daftar ini mengikuti struktur menu di prototipe. Semua sudah dibangun dan diuji di prototipe kecuali ditandai lain.

## Autentikasi & Onboarding
- [x] Login simulasi Google (pilih akun) dan Email + password
- [x] Verifikasi 2FA untuk Administrator
- [x] Undangan lewat email (tautan sekali pakai, berlaku 7 hari) — role dipilih saat undang; departemen (label) diisi belakangan lewat profil
- [x] Pendaftaran mandiri → masuk status "Menunggu persetujuan", Administrator/Pengelola yang approve memilih role-nya
- [x] **Tambah Pengguna langsung oleh Administrator** — akun langsung aktif tanpa perlu tautan diklik; departemen (label) opsional dicentang saat itu juga, atau ditambah nanti; bisa juga menambah label departemen baru di tempat
- [x] Akun dinonaktifkan (bukan dihapus) supaya riwayat tetap utuh; bisa diaktifkan lagi
- [x] Satu profil bisa punya beberapa email tertaut
- [x] Akun eksternal (email non-domain perusahaan) otomatis dapat tanggal kedaluwarsa akses, bisa diperpanjang

## Role & Departemen (halaman Admin)
- [x] Satu halaman ringkas: Nama, Role (badge), Departemen (label, teks ringkas), tombol Edit
- [x] Edit per orang lewat panel: pilih Role (dropdown 4 pilihan) + centang departemen (label, tidak memengaruhi akses)
- [x] Sistem menolak menurunkan Administrator aktif terakhir

## Task & Sub-task
- [x] Task induk + satu tingkat sub-task, penomoran otomatis format `KODEPROJECT-N` dan `KODEPROJECT-N.M`
- [x] Pembuatan cepat: kotak textarea "satu baris = satu sub-task" saat membuat task, atau tempel multi-baris sekaligus di drawer task yang sudah ada
- [x] Template task berulang (checklist sub-task + durasi per sub-task), dengan opsi "Urutan wajib"
- [x] Field terkunci (judul/deadline/prioritas/departemen) untuk PIC yang bukan pembuat task sendiri — lihat `03-roles-permissions.md`
- [x] Tombol aksi cepat sub-task dengan warna sesuai status: **abu-abu** (▶ belum dikerjakan) → **oranye** (✓ sedang dikerjakan) → **hijau** (✓ selesai, jadi lencana statis)
- [x] Notifikasi otomatis "giliran kamu" untuk PIC sub-task berikutnya, saat "Urutan wajib" aktif dan sub-task sebelumnya baru selesai
- [x] PIC bisa CRUD penuh sub-task di bawah task induknya sendiri, bukan cuma sub-task miliknya sendiri
- [x] "Dibuat oleh" ditampilkan di detail task
- [x] Riwayat pengalihan PIC ditampilkan di detail task
- [x] Lampiran file per task (upload/lihat/hapus) — **lihat catatan penyimpanan di `08-known-gaps.md`**
- [x] Komentar bebas per task

## Project
- [x] CRUD penuh: Tambah, Edit (nama+kode), Hapus (otomatis terkunci kalau masih ada task di dalamnya)
- [x] Kode dipakai sebagai awalan nomor task, konsisten untuk semua orang
- [x] Filter Project (dropdown) terpisah dari filter Departemen (dropdown) di Papan/Jadwal/Laporan
- [x] Tag Project tampil di kartu task dan header detail task
- [x] Task bisa dipindah ke Project lain setelah dibuat (Administrator/Pengelola), nomor otomatis menyesuaikan

## Papan (Kanban)
- [x] Lima kolom: To do, On Progress, Revisi, On Review, Done — lihat `04-task-lifecycle.md` untuk aturan Done
- [x] Drag-and-drop kartu antar kolom, atau lewat dropdown cepat di kartu
- [x] Task dengan sub-task tidak bisa dipindah manual — statusnya mengikuti sub-task
- [x] Tombol closing (Tinjau & Closing / Closing Langsung) langsung di kartu kolom Done, untuk Administrator/Pengelola

## Jadwal (Daftar + Timeline digabung)
- [x] Kolom bisa disembunyikan/ditampilkan satu per satu (PIC, Progress, Priority, Start, End, Remarks) — lebar timeline menyesuaikan otomatis
- [x] Kalender pemilih rentang tanggal (klik tanggal mulai → klik tanggal akhir → highlight rentang)
- [x] "Lompat ke" bulan tertentu di timeline
- [x] Terhubung langsung dengan Papan — ubah status/progress di salah satu, otomatis sinkron di yang lain
- [x] Daftar flat (tidak lagi dikelompokkan per departemen — departemen cuma jadi filter, bukan pengelompokan tampilan)

## Review (halaman gabungan)
- [x] Bagian "Perlu keputusanmu sebagai reviewer" — muncul kalau ada
- [x] Bagian "Menunggu closing" — khusus Administrator/Pengelola, muncul kalau ada
- [x] Kedua bagian bersembunyi sendiri-sendiri kalau kosong (tidak ada judul menggantung)

## Import Excel
- [x] Alur: unggah → preview → konfirmasi → task dibuat
- [x] Preview menangani: hierarki tidak valid, PIC tidak cocok, tanggal ambigu, status vs progress bertentangan
- [x] Batalkan satu batch import sekaligus
- [x] Import ulang: baris dengan ID yang ada memperbarui, tanpa ID membuat baru

## Laporan
- [x] Dikelompokkan per Project (bukan per departemen)
- [x] Berfungsi sekaligus sebagai arsip (task Done-dan-closing tetap tampil di sini)
- [x] Tombol "Salin sebagai TSV" untuk tempel manual ke Google Sheets (tab Laporan/Gantt di sheet pakai rumus, baca dari tab Data — supaya tidak rusak kalau ada yang salah edit manual di tab Data)

## Notifikasi
- [x] Pemicu: task baru ditugaskan, status/progress diubah orang lain, tenggat dekat/lewat, ringkasan import selesai, giliran sub-task berurutan, alur review (diajukan/disetujui/ditolak/closing)
- [x] Preferensi personal per jenis notifikasi (bisa dimatikan sebagian)
- [x] Catatan izin notifikasi Android 13+ (khusus merek yang agresif mematikan notifikasi latar belakang)

## Log Aktivitas
- [x] Tidak bisa diubah/dihapus siapa pun
- [x] Filter per kategori: Login, Perubahan role, Undangan, Import, Task terbatas, Review & closing PMO, Project, Penghapusan, Akses, Pengaturan

## Pengaturan sistem (Administrator)
- [x] Progress induk: rata jumlah Done vs berbobot durasi sub-task
- [x] Default kedaluwarsa akses eksternal
- [x] Wajib 2FA untuk Administrator
- [x] Default flag "Terbatas" untuk task baru di Legal

## Tampilan Android (pratinjau konsep mobile)
- [x] Ringkasan "Task saya", kotak notifikasi, pengaturan — versi ringkas dari fitur desktop
- [x] Warna tombol sub-task konsisten dengan desktop
- [x] Kontrol status/progress terkunci saat task sedang `On Review`/`Revisi`, sama seperti desktop

## Modul terpisah yang ditemukan di kode tapi TIDAK tercakup riwayat diskusi
- **Purchase Request** — alur persetujuan berjenjang (GA → HRGA → Direktur) dengan objek data sendiri. Ada di navigasi dan tampaknya fungsional, tapi spesifikasi lengkapnya (aturan, siapa yang boleh membuat, dsb.) tidak tercakup dalam rangkuman percakapan yang menjadi dasar dokumen ini. **Perlu digali ulang langsung dari kode prototipe dan/atau didiskusikan dengan pemilik produk** sebelum dibawa ke produksi.
