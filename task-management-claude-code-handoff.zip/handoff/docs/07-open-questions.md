# Asumsi yang Diambil & Pertanyaan Terbuka

Selama membangun prototipe, beberapa keputusan diambil tanpa konfirmasi eksplisit dari pemilik produk karena percakapan berjalan iteratif dan sebagian pertanyaan tidak pernah dijawab langsung. Semuanya **masuk akal dan konsisten**, tapi sebaiknya dikonfirmasi ulang sebelum atau selagi membangun versi produksi — terutama yang ditandai **(belum dikonfirmasi)**.

## Terkait Role & Akses

1. **(belum dikonfirmasi)** Kandidat reviewer dan PIC bebas dipilih dari **siapa saja** (tidak difilter berdasarkan label departemen). Ini konsisten dengan prinsip "departemen cuma label", tapi pemilik produk belum pernah menjawab pertanyaan ini secara eksplisit saat ditanyakan.
2. **(belum dikonfirmasi)** Cakupan persis "Pengelola: akses penuh kecuali undang/tambah pengguna" — di prototipe, cakupan yang **dikecualikan** dari Pengelola adalah: mengundang/menambah pengguna baru, mengubah role orang lain, akses halaman Pengaturan sistem. Sedangkan CRUD Project dan CRUD task tetap diberikan ke Pengelola. Perlu dipastikan pembagian ini sesuai maksud pemilik produk, terutama soal Project dan Pengaturan sistem — apakah itu dua hal yang PERLU tetap Administrator-only, atau memang boleh ikut Pengelola.
3. Reviewer boleh siapa saja, tidak harus role tertentu (Administrator/Pengelola/Member semua bisa jadi reviewer kalau ditunjuk).

## Terkait Alur Review

4. Reject cukup satu orang untuk menahan task masuk Revisi; Accept butuh bulat (semua reviewer). — **sudah dikonfirmasi eksplisit** oleh pemilik produk.
5. Setelah direvisi dan diajukan ulang, **seluruh** reviewer menilai dari nol (termasuk yang sebelumnya sudah Accept) — **sudah dikonfirmasi eksplisit**.
6. Status `On Review` dan `Revisi` **tidak dihitung sebagai Done** untuk keperluan progress task induk — hanya status Done sungguhan yang dihitung. Ini konsisten dengan rumus progress yang sudah disepakati, tapi belum ditanyakan secara spesifik untuk kombinasi status baru ini.
7. Notifikasi giliran sub-task berurutan **hanya berlaku kalau "Urutan wajib" aktif** pada task itu — untuk sub-task yang boleh dikerjakan sembarang urutan, tidak ada "task selanjutnya" yang jelas untuk dikirimi notifikasi.

## Terkait Project

8. Task gabungan (induk + sub-task) **wajib satu Project yang sama**, tidak bisa lintas-Project — pemilik produk sendiri menandai ini perlu dikonfirmasi ulang saat spek Project pertama kali dibahas, dan pilihan ini diambil supaya jelas task itu muncul di board Project mana.
9. Kode Project di-generate otomatis dari nama kalau tidak diisi manual (inisial tiap kata, atau tiga huruf pertama kalau cuma satu kata) — aturan generate ini murni keputusan implementasi, belum pernah dibahas eksplisit bentuknya.

## Terkait Data & Skala

10. Belum ada aturan retensi data (berapa lama data lama disimpan) atau syarat lokasi server — pertanyaan ini muncul di rancangan paling awal proyek dan belum pernah dijawab di sepanjang percakapan.
11. Backend: prototipe tidak menentukan pilihan platform (Firebase/Supabase vs Node+Postgres) — keputusan ini eksplisit diserahkan ke tahap berikutnya, lihat `README.md`.
12. Siapa yang merawat sistem setelah rilis (dukungan teknis jangka panjang) — juga belum pernah dijawab.

## Terkait Modul di Luar Cakupan

13. **Purchase Request** — modul ini ditemukan sudah ada di kode prototipe (alur GA → HRGA → Direktur) tapi spesifikasinya sama sekali tidak tercakup dalam riwayat diskusi yang jadi dasar dokumen-dokumen ini. Statusnya sepenuhnya terbuka — perlu digali ulang dari kode dan/atau ditanyakan langsung ke pemilik produk.
