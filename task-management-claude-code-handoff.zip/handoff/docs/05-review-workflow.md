# Alur Review Berlapis dan Closing

Ini bagian paling rumit di aplikasi — dibaca pelan-pelan, banyak aturan kecil yang saling bergantung.

## 1. Menentukan reviewer (saat task dibuat)

- Reviewer ditentukan oleh **pembuat task** (Administrator/Pengelola), saat task pertama kali dibuat.
- **Reviewer bersifat opsional** — boleh nol, satu, atau lebih dari satu orang.
- Kandidat reviewer **tidak difilter berdasarkan departemen** — bebas siapa saja (akun aktif mana pun). Ini konsisten dengan aturan "departemen cuma label" di `03-roles-permissions.md`.
- Reviewer **tidak bisa mengubah field task apa pun** — perannya murni menilai: Accept atau Reject.

## 2. Mengajukan review (dilakukan PIC)

- Tombol "Ajukan untuk Review" muncul di task induk ketika statusnya `On Progress`.
- Begitu diajukan:
  - **Kalau tidak ada reviewer sama sekali** → task langsung berstatus `Done` (progress dipaksa 100%), notifikasi terkirim ke seluruh Administrator/Pengelola bahwa ada task menunggu closing.
  - **Kalau ada reviewer** → status jadi `On Review`, setiap reviewer di daftar `reviewers[]` mendapat notifikasi.

## 3. Reviewer memutuskan

- Setiap reviewer memutuskan **secara terpisah**: Accept atau Reject.
- Reject **wajib** disertai catatan alasan (field bebas, tidak boleh kosong).
- Selama ada reviewer yang **belum** memutuskan, status task tetap `On Review` — tidak ada perubahan apa pun, termasuk kalau sebagian reviewer sudah memutuskan. Tampilkan progres keputusan, mis. **"1/2 sudah menilai"**, supaya orang tahu tanpa harus membuka detail.
- Keputusan tiap reviewer **disimpan terpisah** (nama, waktu, catatan) dan **selalu ditampilkan sebagai daftar** di halaman detail task — bukan cuma muncul sementara pas lagi `On Review`. Ini termasuk saat task sudah `Revisi` atau bahkan sudah `Done` (untuk transparansi/audit).

## 4. Menentukan hasil akhir (baru diproses setelah SEMUA reviewer memutuskan)

| Kondisi | Hasil |
|---|---|
| **Semua reviewer Accept** | Status → `Done` (progress 100%). Notifikasi ke PIC dan ke seluruh Administrator/Pengelola bahwa task menunggu closing. |
| **Ada minimal satu Reject** | Status → `Revisi`. Task balik ke papan PIC untuk diperbaiki. **Reject cukup satu orang untuk menahan task — tidak perlu mayoritas.** Accept butuh bulat (unanimous). |

## 5. Setelah direvisi — mengajukan ulang

- PIC memperbaiki task (field terkunci tetap terkunci — lihat `03-roles-permissions.md`), lalu mengajukan ulang lewat tombol yang sama.
- Pengajuan ulang mereset **seluruh** keputusan reviewer ke "belum menilai" — **termasuk reviewer yang sebelumnya sudah Accept**. Alasannya: revisi bisa saja mengubah sesuatu yang tadinya sudah disetujui reviewer lain, jadi semua harus menilai ulang dari nol.
- Putaran review sebelumnya (siapa memutuskan apa, kapan) disimpan ke riwayat (`reviewRounds`) sebelum direset, supaya jejaknya tidak hilang.
- Reviewer boleh diganti sebagian/seluruhnya saat mengajukan ulang, atau tetap memakai reviewer yang sama — keputusan pembuat task/PMO.

## 6. Closing oleh Administrator/Pengelola

Begitu task mencapai `Done` (semua reviewer Accept, atau tanpa reviewer sama sekali), task masuk daftar "menunggu closing" dengan dua pilihan:

- **"Tinjau & Closing"** — buka detail lengkap task dulu sebelum menutupnya.
- **"Closing Langsung"** — percaya pada hasil review, langsung tutup tanpa membuka detail.

Kedua jalur ini **wajib tercatat di log aktivitas** untuk keperluan audit: siapa yang closing, kapan, lewat jalur mana. Field `closeVia` menyimpan `'tinjau'` atau `'langsung'`.

Setelah closing: task hilang dari board Kanban, tetap ada di Laporan sebagai arsip, dan **tidak bisa diedit siapa pun lagi**.

## 7. Pengalihan PIC (khusus Administrator/Pengelola)

- Hanya Administrator/Pengelola yang bisa mengalihkan PIC suatu task.
- Setiap pengalihan **tercatat riwayatnya**: PIC lama, PIC baru, waktu, dan siapa yang melakukannya (`picHistory`).
- Kalau pengalihan dilakukan saat task sedang `On Review` atau `Revisi`, task **otomatis kembali ke `On Progress`** dulu, dan seluruh keputusan reviewer direset — PIC baru dianggap perlu memulai ulang dari awal kerja, bukan lanjut dari titik review.

## Ringkasan aturan yang sering salah diimplementasikan ulang

- ❌ Jangan biarkan status `Done` tercapai lewat progress manual 100% — harus lewat alur review/tanpa-reviewer di atas.
- ❌ Jangan hapus keputusan reviewer dari tampilan begitu status berubah — riwayatnya harus tetap terlihat.
- ❌ Jangan filter kandidat reviewer berdasarkan departemen.
- ❌ Jangan biarkan reviewer mengedit field task apa pun selain memberi keputusan Accept/Reject + catatan.
- ✅ Reject butuh satu orang saja; Accept butuh semua orang.
- ✅ Task Done-belum-ditutup tetap tampil di board; task Done-dan-ditutup baru hilang dari board.
