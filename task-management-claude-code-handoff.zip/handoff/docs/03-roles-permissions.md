# Role dan Izin Akses

> Ini adalah desain **final** yang berlaku. Kalau ada dokumen atau riwayat diskusi lama yang menyebut "Manager per departemen", "Viewer", atau akses yang dibatasi per-departemen — itu desain lama yang sudah digantikan total oleh model di bawah ini.

## Empat role global

Role melekat pada **akun**, bukan pada departemen. Satu akun cuma punya satu role.

| Role | Lihat task | Ubah/hapus task siapa saja | Undang/tambah pengguna, ubah role orang lain |
|---|---|---|---|
| **Administrator** | Semua, di semua departemen | Ya | Ya |
| **Pengelola** | Semua, di semua departemen | Ya | Tidak |
| **Member** | Hanya task yang dia PIC-nya, atau task yang dia buat sendiri | Hanya task miliknya sendiri | Tidak |
| **Guest** | Semua, di semua departemen (baca saja) | Tidak — sama sekali tidak bisa mengubah apa pun | Tidak |

**Pengelola** adalah gabungan dari role-role lama yang sudah dihapus: **Manager** (per departemen), **PMO**, dan **Direktur**. Kalau menemukan istilah-istilah itu di riwayat lama, anggap semuanya setara Pengelola sekarang.

**Departemen (field `depts` di User) murni label profil** — tidak dicek di mana pun untuk keputusan izin akses. Jangan menaruh logika "kalau `user.depts` mengandung X" di manapun kecuali untuk keperluan tampilan (mis. menampilkan "IT · GA" di bawah nama orang).

## Aturan "Terbatas" (restricted) di level Task

Task individual (bukan role) bisa ditandai **Terbatas**. Kalau ditandai:
- Yang bisa melihat: **PIC task itu** (termasuk PIC salah satu sub-tasknya), **Administrator**, **Pengelola**.
- Member/Guest yang bukan PIC — task ini seolah tidak ada buat mereka (tidak muncul di daftar mana pun).

Legal punya kebijakan default: task baru di departemen Legal otomatis diberi tanda Terbatas (bisa dicabut manual oleh Pengelola/Administrator per task). Ini pengaturan sistem yang bisa dimatikan.

## Pengecualian visibilitas untuk Member: "task gabungan"

Ini aturan yang paling sering salah diimplementasikan ulang kalau tidak hati-hati, jadi ditulis eksplisit dengan contoh:

> Task induk **selalu terlihat penuh** (judul, deskripsi, timeline, project, departemen) oleh Member yang menjadi PIC di **salah satu sub-tasknya** — meskipun Member itu bukan PIC dari task induknya sendiri.
>
> **Contoh:** Task induk "Pembelian CCTV" (PIC: A) punya sub-task "Request Form" (PIC: A) dan "Pemasangan" (PIC: B). Member B tetap bisa membuka dan melihat task induk "Pembelian CCTV" secara penuh, karena dia PIC di salah satu sub-tasknya — walau task induknya sendiri bukan miliknya.
>
> **Tapi** — sub-task "Request Form" (milik A) tetap **hanya tampil ringkas** buat B (judul, status, nama PIC saja) — B tidak bisa membuka detailnya atau mengeditnya, karena dia bukan PIC di sub-task itu.

Ini berlaku HANYA untuk Member. Administrator/Pengelola/Guest sudah melihat semuanya lewat aturan dasar di atas.

## Field yang terkunci di level Task ("locked fields")

Empat field ini — **judul, deadline (start/end), prioritas, departemen** — dianggap keputusan yang dibuat saat task dibuat, bukan keputusan pelaksana:

| Siapa | Bisa ubah field terkunci? |
|---|---|
| Administrator, Pengelola | Selalu bisa, kapan pun (kecuali task sudah Done — lihat catatan Arsip di bawah) |
| PIC yang **juga pembuat task itu sendiri** (task dibuat lewat alur "buat task untuk diri sendiri") | Bisa mengubah task miliknya sendiri |
| PIC yang bukan pembuat task (task dibuat/ditugaskan oleh orang lain) | **Tidak bisa** — harus minta Administrator/Pengelola |

Field lain (Remarks, sub-task, PIC lampiran) tetap bisa diubah PIC selama task belum Done, mengikuti aturan CRUD biasa di bawah.

## Siapa boleh membuat task

- **Administrator, Pengelola**: bisa membuat task untuk siapa saja, di departemen dan Project mana saja.
- **Member**: bisa membuat task, **hanya untuk dirinya sendiri sebagai PIC** — field PIC otomatis terkunci ke namanya sendiri saat membuat task, tidak bisa ditugaskan ke orang lain.
- **Guest**: tidak bisa membuat task sama sekali.

## Task yang sudah Done (dan sudah di-closing PMO) bersifat abadi/read-only

Begitu status task = `Done` **dan** `closeVia` sudah terisi (benar-benar ditutup, bukan sekadar mencapai status Done), task itu:
- Tidak bisa diedit siapa pun lagi, termasuk Administrator dan Pengelola.
- Tidak lagi tampil di board Kanban.
- Tetap tampil di Laporan (berfungsi sebagai arsip).

## Ringkasan fungsi-fungsi izin akses (referensi, bukan kode literal)

Kalau membangun ulang, fungsi-fungsi pemeriksaan izin yang perlu ada kurang lebih:

- `canSeeFull(task, user)` — bisa buka & lihat detail penuh
- `canSee(task, user)` — task muncul di daftar mana pun (termasuk yang cuma ringkas)
- `canEdit(task, user)` — bisa ubah field non-terkunci (remarks, status, progress, sub-task)
- `canEditLockedFields(task, user)` — bisa ubah judul/deadline/prioritas/departemen
- `canCreateTaskForAnyone(user)` — Administrator/Pengelola
- `canCreateTaskForSelf(user)` — di atas, ditambah Member
- `isReviewerAuthority(user)` — Administrator/Pengelola (dipakai untuk closing PMO dan pengalihan PIC)

Semua fungsi ini di prototipe **tidak pernah membaca `task.dept` atau `user.depts` untuk keputusan izin** — hanya membaca `role`, kepemilikan PIC, dan status task.
