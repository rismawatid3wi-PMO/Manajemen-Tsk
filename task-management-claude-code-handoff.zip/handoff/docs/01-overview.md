# Konteks Bisnis

## Masalah yang ingin diselesaikan

Tim **IT, Admin, Legal, dan GA** di sebuah perusahaan mengelola task operasional lewat spreadsheet (Google Sheets/Excel) dengan format kolom: `No, Task, Assigned To, Progress, Status, Priority, Start, End, Remarks`, plus Gantt chart mingguan yang diperbarui manual.

Masalah dengan pendekatan ini:
- Tidak ada kontrol siapa boleh mengubah apa — siapa saja yang punya akses ke file bisa mengubah baris siapa pun.
- Tidak ada jejak riwayat perubahan yang bisa diandalkan (siapa mengubah apa, kapan).
- Tidak ada alur persetujuan — task "selesai" hanya berdasarkan kata orang yang mengerjakannya, tidak ada verifikasi berjenjang.
- Sub-task manual (baris 1.1, 1.2 di bawah baris 1) rawan salah hitung progres induknya.
- Tidak ada notifikasi otomatis — orang harus rutin membuka sheet untuk tahu ada task baru atau tenggat mendekat.

## Tujuan aplikasi baru

Pindahkan proses ini ke aplikasi web yang:
1. **Tetap terasa familiar** — mengikuti bentuk kolom yang sudah biasa dipakai (No, Task, PIC, Progress, Status, Priority, Start, End, Remarks) supaya tidak perlu pelatihan ulang besar-besaran.
2. **Menambahkan kontrol akses** berbasis role, bukan sekadar "siapa saja yang punya link."
3. **Menambahkan alur persetujuan berjenjang** sebelum task dianggap benar-benar tuntas.
4. **Mengotomatiskan** perhitungan progres induk dari sub-task, penomoran, dan notifikasi.
5. Tetap menyediakan jalan keluar ke **Google Sheets** untuk kebutuhan pelaporan yang sudah terbiasa dipakai manajemen (lihat `docs/06-features-list.md` bagian Laporan).

## Unit organisasi

Ada empat departemen: **IT, Admin (Administrasi), Legal (Hukum), GA (General Affairs)**. Struktur organisasi menempatkan seluruh departemen ini di bawah tiga pihak: **PMO, Direktur, dan IT Manager** — yang belakangan konsepnya disederhanakan lagi menjadi role **Pengelola** yang berlaku lintas departemen (lihat `docs/03-roles-permissions.md`).

Penting: dalam desain final, **departemen tidak lagi membatasi akses** — departemen kini murni label/jabatan di profil seseorang. Ini adalah keputusan desain yang datang belakangan dalam proses (lihat riwayat keputusan di `docs/07-open-questions.md`), menggantikan model awal yang tadinya membatasi akses per-departemen. Siapa pun yang membaca riwayat commit/rancangan lama dan menemukan referensi "Manager IT", "Member Legal", dsb. sebagai *role dengan hak akses terbatas ke satu departemen* — itu adalah desain LAMA yang **sudah digantikan**. Rujukan yang berlaku adalah `docs/03-roles-permissions.md`.

## Konsep inti yang perlu dipahami sebelum membaca dokumen lain

- **Task** bisa berdiri sendiri, atau menjadi **task induk** dengan satu tingkat **sub-task** (tidak ada sub-sub-task).
- **Project** adalah pengelompokan lintas-departemen yang terpisah dari Departemen — dipakai untuk penomoran dan pelaporan, bukan untuk kontrol akses.
- Sebuah task melewati alur status yang cukup panjang sebelum dianggap tuntas dan diarsipkan: lihat `docs/04-task-lifecycle.md`.
- Ada dua alur persetujuan berbeda yang perlu dibedakan dengan jelas: **penilaian oleh reviewer** (Accept/Reject) dan **closing oleh PMO/Pengelola** — keduanya wajib dan berurutan, dijelaskan di `docs/05-review-workflow.md`.
