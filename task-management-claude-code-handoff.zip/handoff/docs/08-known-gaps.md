# Batasan Prototipe & Hal yang Sengaja Belum Dikerjakan

Ini bukan daftar bug — ini batasan yang **wajar untuk sebuah prototipe klik** (tanpa backend), yang perlu penanganan sungguhan saat dibangun jadi aplikasi produksi.

## Semua ini murni simulasi, belum ada implementasi sungguhan

- **Autentikasi**: login Google dan email/password cuma simulasi UI (klik "pilih akun", tidak ada OAuth sungguhan; password tidak pernah benar-benar diperiksa). Produksi butuh OAuth provider sungguhan (Google) dan penyimpanan password ter-hash dengan benar (bukan disimpan plaintext).
- **2FA**: alur UI-nya ada, tapi tidak ada pengiriman kode sungguhan.
- **Notifikasi push**: cuma simulasi banner di layar. Produksi butuh integrasi FCM (Firebase Cloud Messaging) atau setara, plus penanganan izin notifikasi Android 13+ yang disebut di catatan aplikasi.
- **Sinkronisasi Google Sheets**: cuma tombol "salin sebagai TSV" untuk tempel manual. Kalau memang perlu otomatis, butuh integrasi Google Sheets API tersendiri (di luar cakupan yang pernah dibahas).
- **Import Excel**: parsing dan validasi berjalan di sisi klien (browser) dengan data yang sudah disiapkan sebagai contoh. Produksi butuh parser file Excel sungguhan (`.xlsx`) di sisi server plus validasi yang sama ketatnya.
- **Lampiran file**: disimpan sebagai data URI di memori browser (hilang begitu tab ditutup). Produksi wajib pakai object storage sungguhan (S3-compatible, Google Cloud Storage, dst.) dengan URL/token akses per file, bukan menyimpan isi file langsung di database.

## Penyimpanan data

Semua data (task, pengguna, project, log) hidup di **memori JavaScript** selama sesi browser terbuka — tidak ada database sungguhan, tidak ada persistensi antar sesi. Ini sepenuhnya diharapkan untuk prototipe; seluruh isi `docs/02-data-model.md` disusun supaya bisa langsung dipetakan ke skema database sungguhan (tabel/collection per entitas).

## Yang secara sadar belum dibangun (bukan lupa, tapi keputusan menunggu kebutuhan nyata)

- **Halaman "Sub-task saya" lintas-task** — didiskusikan sebagai kemungkinan tambahan (mengumpulkan semua sub-task aktif seseorang dari berbagai task induk berbeda dalam satu tampilan), tapi disepakati untuk **ditunda** sampai ada bukti nyata orang kewalahan dengan tampilan "Task saya" yang sudah ada di Beranda saat ini.
- **Pengingat otomatis untuk reviewer yang lambat memutuskan** — belum ada mekanisme reminder terjadwal.
- **Filter status di halaman Laporan** (mis. tombol "sembunyikan yang Done") — saat ini Laporan menampilkan semua status apa adanya.

## Hal teknis lain yang perlu perhatian ekstra saat migrasi ke produksi

- **Penomoran task** (`OPS-1`, `CM-3`, dst.) dihitung ulang dari urutan pembuatan setiap kali diperlukan, bukan disimpan sebagai kolom tetap. Ini aman di prototipe (semua data ada di memori, murah dihitung ulang), tapi di database sungguhan dengan volume besar, pertimbangkan meng-cache nomor ini atau menghitungnya lewat query yang diindeks dengan baik, supaya tidak jadi lambat.
- **Log aktivitas** ditulis dari banyak sekali titik berbeda di kode (task, review, project, akses, dll.) — pastikan di produksi ini benar-benar satu sistem logging terpusat yang konsisten formatnya, bukan dipanggil ad-hoc dari tiap fitur.
- **Preferensi notifikasi per pengguna** (`prefs`) perlu benar-benar dicek sebelum mengirim setiap notifikasi — jangan sampai notifikasi terkirim ke orang yang sudah mematikan jenis itu.
