# Model Data

Bentuk data ini diambil langsung dari struktur yang dipakai di prototipe (`prototype/task-management-prototipe.html`), bukan cuma rancangan di atas kertas — jadi field yang tercantum di sini sudah terbukti cukup untuk seluruh fitur yang dibangun.

## User (Pengguna)

| Field | Tipe | Keterangan |
|---|---|---|
| `id` | string | ID internal |
| `name` | string | Nama lengkap |
| `email` | string | Email login utama |
| `extra` | string[] | Email tambahan yang ditautkan ke profil yang sama (satu orang bisa punya beberapa email, mis. email pribadi lama + email kantor baru) |
| `via` | `'Google' \| 'Email'` | Metode login |
| `role` | `'Administrator' \| 'Pengelola' \| 'Member' \| 'Guest'` | Role global — lihat `03-roles-permissions.md` |
| `depts` | string[] | Label departemen/jabatan (mis. `['IT','GA']`) — **murni informasi, tidak memengaruhi akses** |
| `active` | boolean | Akun dinonaktifkan (bukan dihapus) supaya riwayat task tetap utuh |
| `expires` | date string \| null | Tanggal kedaluwarsa akses, dipakai untuk akun eksternal (konsultan/kontraktor dengan email non-domain perusahaan) |
| `last` | string | Waktu login terakhir (tampilan) |
| `prefs` | object | Preferensi notifikasi pribadi: `{assign, status, due, late, imp}` (masing-masing boolean, on/off per jenis notifikasi) |

Catatan turunan (tidak perlu disimpan terpisah di database, bisa dihitung dari `role`):
- `admin` = `role === 'Administrator'`
- Hak setara "Pengelola lama" (dulu PMO/Direktur/Manager) = `role === 'Administrator' || role === 'Pengelola'`

## Task

Satu entitas dipakai untuk **task induk** maupun **sub-task** (sub-task adalah baris Task juga, dibedakan lewat `parent`). Hanya ada **satu tingkat** sub-task — sub-task tidak boleh punya sub-task lagi.

| Field | Tipe | Keterangan |
|---|---|---|
| `id` | string | ID internal |
| `dept` | string | Departemen "pemilik" task (label pelaporan, bukan pembatas akses) |
| `project` | string \| null | ID Project. **Hanya diisi di task induk** (`null` di sub-task — sub-task mengikuti project induknya) |
| `parent` | string \| null | ID task induk. `null` berarti ini task induk (root) |
| `title` | string | Judul |
| `progress` | number (0–100) | Untuk task induk yang punya sub-task, ini **dihitung otomatis** dari sub-task (lihat `04-task-lifecycle.md`) |
| `status` | enum | `'To do' \| 'On Progress' \| 'Revisi' \| 'On Review' \| 'Done'` |
| `prio` | `'High' \| 'Medium' \| 'Low'` | Sub-task mewarisi prioritas induknya, tidak diedit sendiri |
| `start`, `end` | date string \| null | Untuk task induk dengan sub-task, tanggal ini dihitung otomatis (paling awal/akhir dari sub-task) |
| `remarks` | string | Catatan bebas |
| `restricted` | boolean | Flag "Terbatas" — membatasi siapa yang bisa melihat (lihat `03-roles-permissions.md`) |
| `pic` | `{uid?: string, team?: string}[]` | Bisa lebih dari satu PIC; PIC boleh berupa akun terdaftar (`uid`) atau nama tim bebas berupa teks (`team`, tanpa akun) |
| `by` | string (user id) | Siapa yang membuat task ini |
| `ord` | number | Urutan pembuatan (dipakai untuk penomoran tampilan, lihat bagian Project di bawah) |
| `sequential` | boolean | Kalau `true`, sub-task di bawah task ini terkunci berurutan (sub-task ke-2 tidak bisa dikerjakan sebelum sub-task ke-1 mencapai progress 100) |
| `doneOn` | date string \| null | Tanggal task berstatus Done |
| `reviewers` | `{uid, decision, note, at}[]` | Lihat `05-review-workflow.md`. **Opsional** — task boleh tidak punya reviewer sama sekali |
| `reviewApproved` | boolean | `true` kalau semua reviewer sudah Accept (atau tidak ada reviewer sama sekali) — task siap ditutup PMO |
| `reviewRounds` | array | Riwayat putaran review sebelumnya (diisi ulang setiap kali task ditolak lalu diajukan ulang) |
| `closeVia` | `'langsung' \| 'tinjau' \| null` | Jalur closing PMO yang dipakai — `null` berarti task berstatus Done tapi **belum** benar-benar ditutup (masih tampil di board) |
| `picHistory` | `{from, to, at, by}[]` | Riwayat pengalihan PIC |
| `comments` | array | Komentar bebas pada task |
| `attachments` | `{name, size, data, by, at}[]` | Lampiran file (disimpan sebagai data URI di prototipe — di produksi ini harus diganti object storage sungguhan, lihat `08-known-gaps.md`) |
| `history` | `{at, who, text}[]` | Log kronologis khusus task ini (terpisah dari log aktivitas global) |
| `batch` | string \| null | ID batch import, untuk fitur "batalkan satu batch import" |
| `upd` | string | Waktu update terakhir (tampilan) |

## Project

| Field | Tipe | Keterangan |
|---|---|---|
| `id` | string | ID internal |
| `name` | string | Nama tampilan, mis. "Operasional Kantor" |
| `code` | string | Kode singkat 2–6 huruf, dipakai sebagai awalan nomor task, mis. `OPS`, `CM` |

Project **tidak dibatasi jumlahnya** — bisa ditambah kapan saja oleh Administrator. Satu task induk beserta seluruh sub-tasknya wajib berada di **satu Project yang sama** (tidak bisa lintas-Project).

### Penomoran task

Nomor tampilan (`OPS-1`, `OPS-1.1`, `CM-3`, dst.) **dihitung, bukan disimpan** — turunan dari `project.code` + urutan (`ord`) task induk di dalam project itu + urutan sub-task di dalam task induknya. Penomoran ini **konsisten untuk semua orang** yang melihatnya (tidak berubah tergantung siapa yang login), meski task tertentu mungkin tidak terlihat oleh sebagian orang karena aturan visibilitas.

## Invite / Undangan

| Field | Keterangan |
|---|---|
| `email`, `role` | Role yang akan diterima kalau undangan diterima |
| `dept` | *(Ditinggalkan di alur undangan terbaru — departemen diisi belakangan lewat profil setelah akun aktif, bukan saat undang)* |
| `by`, `exp`, `status` | Siapa mengundang, kedaluwarsa (7 hari), status (`Menunggu`/`Diterima`) |

## Pendaftaran mandiri (self-registration → menunggu persetujuan)

Orang bisa mencoba mendaftar sendiri (bukan lewat undangan) dan masuk ke status "Menunggu persetujuan" — Administrator/Pengelola yang menyetujui memilih role untuk orang itu saat approve.

## Notifikasi

Setiap notifikasi berisi: tipe (assign/status/due/late/import), teks, daftar penerima (`uid[]`), waktu, status baca. Preferensi `prefs` di level User menentukan jenis mana yang benar-benar sampai ke seseorang.

## Log Aktivitas

Catatan global, tidak bisa diubah/dihapus, dengan kategori: `login, role, undangan, import, task, review, project, hapus, akses, pengaturan`. Setiap kategori punya filter sendiri di halaman Log Aktivitas.
