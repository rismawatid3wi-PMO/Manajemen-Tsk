# Aplikasi Task Management — IT · Admin · Legal · GA

> Paket ini disiapkan untuk dibawa ke **Claude Code** agar bisa dilanjutkan menjadi aplikasi produksi sungguhan. Isinya: konsep bisnis, model data, aturan izin akses, alur kerja, dan satu prototipe HTML fungsional sebagai referensi perilaku/tampilan yang sudah divalidasi.

## Cara pakai paket ini

1. Baca `docs/01-overview.md` dulu untuk konteks bisnis.
2. Baca `docs/02-data-model.md` dan `docs/03-roles-permissions.md` — ini fondasi yang paling sering direferensikan bagian lain.
3. `docs/04-task-lifecycle.md` dan `docs/05-review-workflow.md` adalah bagian paling rumit dan paling penting untuk dipahami benar sebelum coding — alur status task dan alur review berlapis adalah inti aplikasi ini.
4. `docs/06-features-list.md` adalah checklist fitur lengkap, berguna sebagai acuan cakupan (scope) dan untuk memecah pekerjaan jadi task-task kecil.
5. `docs/07-open-questions.md` — asumsi yang diambil selama prototyping dan **belum dikonfirmasi pemilik produk**. Sebaiknya dikonfirmasi ulang sebelum atau selagi membangun versi produksi.
6. `docs/08-known-gaps.md` — batasan sengaja di prototipe (bukan bug) dan bagian yang sengaja belum dikerjakan.
7. `prototype/task-management-prototipe.html` — prototipe klik yang *sudah teruji* untuk hampir semua alur di atas. Kalau ada bagian dokumen yang ambigu, prototipe ini adalah sumber kebenaran perilaku sebenarnya (isi datanya cuma simulasi di memori browser, tidak ada backend sungguhan).

## Ringkasan satu paragraf

Empat departemen (IT, Admin, Legal, GA) sekarang mengelola task lewat spreadsheet manual. Aplikasi ini memindahkan itu ke web app dengan: role global (bukan lagi per-departemen), task bertingkat dengan sub-task, dua Project pengelompokan lintas-departemen, alur pembuatan task yang dibatasi peran tertentu, dan alur persetujuan berlapis (reviewer lalu closing PMO) sebelum sebuah task benar-benar dianggap tuntas dan diarsipkan.

## Rekomendasi stack (belum final, silakan disesuaikan)

Prototipe ini murni front-end (HTML+JS, state di memori, tanpa backend). Untuk versi produksi, dokumen rancangan awal proyek ini menyarankan dua opsi:

- **Cepat jalan**: Firebase atau Supabase (auth siap pakai termasuk Google login, database realtime/Postgres terkelola, push notification terkelola).
- **Kendali penuh**: Node.js/Python + PostgreSQL, auth custom, worker terpisah untuk notifikasi dan sinkronisasi Google Sheets.

Pilihan ini tidak dipatok dalam prototipe — keputusan arsitektur backend diserahkan ke tim yang melanjutkan.

## Yang BUKAN bagian dari cakupan dokumen ini

Ada satu modul terpisah bernama **"Purchase Request"** (alur persetujuan GA → HRGA → Direktur) yang ditemukan sudah ada di file prototipe tapi **tidak didokumentasikan di paket ini** — asal-usul dan spesifikasi lengkapnya tidak tercakup dalam riwayat diskusi yang dirangkum di sini. Kalau modul itu juga perlu dibawa ke produksi, perlu digali/didiskusikan ulang secara terpisah dengan pemilik produk sebelum dikerjakan.
